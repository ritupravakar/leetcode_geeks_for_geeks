import bisect

def closestInterval(arr,N):
    V=[]
    for i in range(0,N):
        V.append([arr[i][0],i])

    V.sort()
    res=[-1 for _ in range(N)]

    for i in range(0,N):
        it=bisect.bisect_left(V,[arr[i][1],0])

        if (it!=len(V)):
            idx=it
            res[i]=V[idx][1]

    return res

if __name__=="__main__":
    arr=[[1,4],[3,4],[2,3]]
    for x in closestInterval(arr,len(arr)):
        print(x,end=" ")