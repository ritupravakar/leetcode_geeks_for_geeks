def partition(arr,l,h):
    pivot=arr[l]
    i=l+1
    j=h
    while (i<=j):
        while (i<=h and arr[i]<pivot):
            i+=1
        while (j>l and arr[j]>pivot):
            j-=1

        if (i<j):
            temp=arr[i]
            arr[i]=arr[j]
            arr[j]=temp
            i+=1
            j-=1
        else:
            i+=1

    arr[l]=arr[j]
    arr[j]=pivot
    return j

def sortArray(arr,l,h):
    if (l>=h):
        return
    pivot=partition(arr,l,h)
    sortArray(arr,l,pivot-1)
    sortArray(arr,pivot+1,h)

def findMaxIntervals(start,end,n,R):
    ans=0
    prev=0
    currActive=0
    i=0
    j=0

    if (start[0]>0):
        ans+=1

    while (i<n and j<n):
        if (start[i]<end[j]):
            i+=1
            currActive+=1
        elif (start[i]>end[j]):
            j+=1
            currActive-=1
        else:
            i+=1
            j+=1
        if (currActive==0):
            ans+=1
    if (end[n-1]<R):
        ans+=1
    return ans

if __name__=='__main__':
    R=10
    N=3
    start=[2,5,8]
    end=[3,9,10]
    sortArray(start,0,N-1)
    sortArray(end,0,N-1)
    print(findMaxIntervals(start,end,N,R))
