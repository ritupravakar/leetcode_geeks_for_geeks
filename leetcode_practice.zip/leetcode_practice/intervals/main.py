MAX=int(1e5+5)

def find_missing(interval):
    vis=[0]*(MAX)

    for i in range(len(interval)):
        start=interval[i][0]
        end=interval[i][1]
        vis[start]+=1
        vis[end+1]-=1

    for i in range(1,MAX):
        vis[i]+=vis[i-1]
        if (vis[i]==0):
            print(i)
            return

interval=[[10,16],[2,8],[1,6],[7,12]]
find_missing(interval)