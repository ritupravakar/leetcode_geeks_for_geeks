
def findOverlapSegment(N,a,b):
    tup=[]
    for i in range(N):
        x=a[i]
        y=b[i]
        tup.append(((x,y),i))

    tup.sort()
    curr=tup[0][0][1]
    currPos=tup[0][1]
    for i in range(1,N):
        Q=tup[i-1][0][0]
        R=tup[i][0][0]
        if Q==R:
            if tup[i-1][0][1]<tup[i][0][1]:
                print(tup[i-1][1],tup[i][1])
            else:
                print(tup[i][1],tup[i-1][1])
            return
        T=tup[i][0][1]
        if (T<=curr):
            print(tup[i][1],currPos)
            return
        else:
            curr=T
            currPos=tup[i][1]
    print("-1","-1",end="")

a=[1,2,3,2,2]
b=[5,10,10,2,15]
N=len(a)
findOverlapSegment(N,a,b)
