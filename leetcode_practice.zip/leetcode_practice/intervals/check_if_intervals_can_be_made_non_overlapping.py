def checkOverlapping(a,b):
    a,b=max(a,b),min(a,b)
    if b[0]<=a[0]<=b[1]:
        return True
    return False

def find(a,i):
    if a[i]==i:
        return i

    a[i]=find(a,a[i])
    return a[i]

def union(a,x,y):
    xs=find(a,x)
    ys=find(a,y)
    if xs==ys:
        return True
    a[ys]=xs
    return False

def checkNonOverlapping(arr,n):
    dsu=[i for i in range(n+1)]
    for i in range(n):
        for j in range(i+1,n):
            if checkOverlapping(arr[i],arr[j]):
                if union(dsu,i,j):
                    return False
    return True

if __name__=="__main__":
    arr=[[1,4],[2,2],[2,3]]
    n=len(arr)
    print("YES" if checkNonOverlapping(arr,n) else "NO")