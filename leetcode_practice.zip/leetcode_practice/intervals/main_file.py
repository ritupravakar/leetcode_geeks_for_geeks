def suggestedProducts(products, searchWord):
    search_word_list=[]
    for i in range(len(searchWord)):
        search_word_list+=[searchWord[0:i+1]]
    from collections import Counter
    products=sorted(products)
    trie=Counter()
    for i in products:
        for j in range(len(i)):
            if trie[i]:
                trie[i]+=[i[0:j+1]]
            else:
                trie[i]=[i[0:j+1]]
    l=[]
    for i in search_word_list:
        word_list=[]
        counter=0
        for key,value in trie.items():
            if i in value and counter<3:
                word_list.append(key)
                counter+=1
        l.append(word_list)
    return l



print(suggestedProducts(products = ["havana"], searchWord = "havana"))