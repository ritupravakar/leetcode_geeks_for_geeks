def assignIntervals(interval,n):
    for i in range(n):
        interval[i].append(i)

    interval.sort(key=lambda x:x[0])
    firstEndTime=-1
    secondEndTime=-1
    find=''
    flag=False

    for i in range(n):
        if interval[i][0]>=firstEndTime:
            firstEndTime=interval[i][1]
            interval[i].append('S')
        elif interval[i][0]>=secondEndTime:
            secondEndTime=interval[i][1]
            interval[i].append('F')
        else:
            flag=True
            break

    if flag:
        print(-1)
    else:
        form=['']*n
        for i in range(n):
            indi=interval[i][2]
            form[indi]=interval[i][3]
        print(form,", ")

if __name__=="__main__":
    intervals=[[360,480],[420,540],[600,660]]
    assignIntervals(intervals,len(intervals))