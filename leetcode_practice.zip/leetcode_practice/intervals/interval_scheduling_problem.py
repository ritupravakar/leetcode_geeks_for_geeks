from queue import PriorityQueue

def maxTwoNonOverLapping(interval):
    interval.sort()
    pq=PriorityQueue()
    ma=0
    ans=0

    for e in interval:
        while not pq.empty():
            if (pq.queue[0][0]>=e[0]):
                break
            qu=pq.get()
            ma=max(ma,qu[1])

        ans=max(ans,ma+e[2])
        pq.put([e[1],e[2]])

    return ans

if __name__=='__main__':
    interval=[[1,3,2],[4,5,2],[1,5,5]]
    maxValue=maxTwoNonOverLapping(interval)
    print(maxValue)