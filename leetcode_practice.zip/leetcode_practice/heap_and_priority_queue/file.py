import sys
from heapq import heappush, heappop


def rob(nums):
        nums1=[0 for i in range(len(nums))]
        nums1[0]=nums[0]
        nums1[1]=nums[1]
        for i in range(2,len(nums)):
            nums1[i]=nums[i]+nums1[i-2]
        print(nums1)
        return max(nums1)
print(rob(nums = [1,3,1]))

"""L=[[None]*(n+1) for i in range(m+1)]
    for i in range(m+1):
        for j in range(n+1):
            if i==0 or j==0:
                L[i][j]=0
            elif X[i-1]==Y[j-1]:
                L[i][j]=L[i-1][j-1]+1
            else:
                L[i][j]=max(L[i-1][j],L[i][j-1])

    return L[m][n]"""