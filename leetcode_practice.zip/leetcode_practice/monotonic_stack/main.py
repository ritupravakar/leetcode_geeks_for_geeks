def dailyTemperatures(temperatures):
    """print(temperatures)
    l=[]
    for i in range(len(temperatures)):
        count=0
        for j in range(i+1,len(temperatures)):
            count+=1
            if temperatures[j]>temperatures[i]:
                l+=[count]
                break
        if count==0:
            l+=[count]
    if temperatures[len(temperatures)-1]!=max(temperatures):
        l+=[0]
    return l"""
    """ans=[0]*len(temperatures)
    stack=[]
    for i,t in enumerate(temperatures):
        while stack and temperatures[stack[-1]]<t:
            cur=stack.pop()
            ans[cur]=i-cur
        stack.append(i)
    return ans"""

    l=[0 for i in range(len(temperatures))]
    stack=[]
    for i in range(len(temperatures)):
        while len(stack) and temperatures[stack[-1]]<temperatures[i]:
            index=stack.pop()
            l[index]=i-index
        stack.append(i)
    return l



print(dailyTemperatures(temperatures= [73,74,75,71,69,72,76,73]))