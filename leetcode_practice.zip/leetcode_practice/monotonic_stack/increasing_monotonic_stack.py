def increasingStack(arr,N):
    stk=[]
    for i in range(N):
        while (len(stk) > 0 and stk[len(stk)-1] > arr[i]):
            stk.pop()
        stk.append(arr[i])
    N2=len(stk)
    ans=[0]*N2
    j=N2 -1

    while (len(stk)!=0):
        ans[j]=stk[len(stk)-1]
        stk.pop()
        j=j-1

    print("The array: ",end=" ")
    for i in range(N):
        print(arr[i],end=" ")
    print()

    print("The stack: ",end=" ")
    for i in range(N2):
        print(ans[i],end=" ")
    print()

arr=[1,4,5,3,12,10]
N=len(arr)

increasingStack(arr,N)