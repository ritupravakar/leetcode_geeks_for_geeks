def positionOfRightmostSetBit(n):
    if n&1:
        return 1
    n=n ^ (n & (n-1))
    pos=0
    while n:
        n=n>>1
        pos=pos+1
    return pos

print(positionOfRightmostSetBit(100))