def findbits(x,y):
    n=x ^ y
    count=0
    while n:
        n=n&(n-1)
        count=count+1
    return count

x=65
y=80
print(findbits(x,y))