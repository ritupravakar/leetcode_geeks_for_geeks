num1=1024
bt1=bin(num1)[2:].zfill(32)
print(bt1)

num2=num1<<1
bt2=bin(num2)[2:].zfill(32)
print(bt2)
num3=num1<<2
bitset13=bin(num3)[2:].zfill(16)
print(bitset13)