def isPowerOfTwo(x):
    return x and (not(x & (x-1)))

print(isPowerOfTwo(100))