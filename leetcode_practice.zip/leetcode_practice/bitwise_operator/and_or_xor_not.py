a=7
b=4
result=a&b
print(result)

a=12
b=25
result=a|b
print(result)

a=12
b=25
result=a^b
print(result)

a=0
print("Inverting using NOT operator with sign bit",(~a))
print("Inverting using NOT operator withour sign bit",int(not(a)))