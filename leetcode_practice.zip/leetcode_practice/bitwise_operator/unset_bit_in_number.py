def unset(num,pos):
    num&=(~(1<<pos))
    print(num)

num,pos=7,1
unset(num,pos)