"""def suggestedProducts(products, searchWord):

    products=sorted(products)
    str1=""
    for i in searchWord:
        str1+=i
        count=0
        l=0
        r=len(products)-1
        while l<=r:
            index=l+(r-l)//2
            if str1 in products[index]:
                r=index
            else:
                l=

            for j in products:


print(suggestedProducts(products = ["mobile","mouse","moneypot","monitor","mousepad"], searchWord = "mouse"))"""