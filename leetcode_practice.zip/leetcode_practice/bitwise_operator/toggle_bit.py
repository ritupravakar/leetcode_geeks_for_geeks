def toggle(num,pos):
    num^=(1<<pos)
    print(num)

num,pos=4,1
toggle(num,pos)