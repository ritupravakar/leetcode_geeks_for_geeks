def set(num,pos):
    num|=(1<<pos)
    print(num)

num,pos=4,1
set(num,pos)