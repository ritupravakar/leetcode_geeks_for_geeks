num=12
ans=num<<1
print(ans)

num=12
ans=num>>1
print(ans)