# https://www.geeksforgeeks.org/detect-cycle-undirected-graph/

"""Follow the below steps to implement the above approach:

    Iterate over all the nodes of the graph and Keep a visited array visited[] to track the visited nodes.
    Run a Depth First Traversal on the given subgraph connected to the current node and pass the parent of the current node. In each recursive
        Set visited[root] as 1.
        Iterate over all adjacent nodes of the current node in the adjacency list
            If it is not visited then run DFS on that node and return true if it returns true.
            Else if the adjacent node is visited and not the parent of the current node then return true.
        Return false."""

from collections import defaultdict
class Graph:
    def __init__(self,vertices):
        self.V=vertices
        self.graph=defaultdict(list)

    def addEdge(self,v,w):
        self.graph[v].append(w)
        self.graph[w].append(v)

    def isCyclicUtil(self,v,visited,parent):
        visited[v]=True
        for i in self.graph[v]:
            if visited[i]==False:
                if (self.isCyclicUtil(i,visited,v)):
                    return True
            elif parent!=i:
                return True
        return False

    def isCyclic(self):
        visited=[False]*(self.V)
        for i in range(self.V):
            if visited[i]==False:
                if (self.isCyclicUtil(i,visited,-1))==True:
                    return True
        return False


g=Graph(5)
g.addEdge(1,0)
g.addEdge(1,2)
g.addEdge(2,0)
g.addEdge(0,3)
g.addEdge(3,4)

if g.isCyclic():
    print("Graph contains cycle")
else:
    print("Graph doesn't contain cycle")

g1=Graph(3)
g1.addEdge(0,1)
g1.addEdge(1,2)

if g1.isCyclic():
    print("Graph contains cycle")
else:
    print("Graph doesn't contain cycle")
