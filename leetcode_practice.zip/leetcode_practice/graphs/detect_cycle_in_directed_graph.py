# https://www.geeksforgeeks.org/detect-cycle-in-a-graph/

"""Follow the below steps to Implement the idea:

    Create a recursive dfs function that has the following parameters – current vertex, visited array, and recursion stack.
    Mark the current node as visited and also mark the index in the recursion stack.
    Iterate a loop for all the vertices and for each vertex, call the recursive function if it is not yet visited (This step is done to make sure that if there is a forest of graphs, we are checking each forest):
        In each recursion call, Find all the adjacent vertices of the current vertex which are not visited:
            If an adjacent vertex is already marked in the recursion stack then return true.
            Otherwise, call the recursive function for that adjacent vertex.
        While returning from the recursion call, unmark the current node from the recursion stack, to represent that the current node is no longer a part of the path being traced.
    If any of the functions returns true, stop the future function calls and return true as the answer.

"""

from collections import defaultdict
class Graph():
    def __init__(self,vertices):
        self.graph=defaultdict(list)
        self.V=vertices

    def addEdge(self,u,v):
        self.graph[u].append(v)

    def isCyclicUtil(self,v,visited,recStack):
        visited[v]=True
        recStack[v]=True
        for neighbour in self.graph[v]:
            if visited[neighbour]==False:
                if self.isCyclicUtil(neighbour,visited,recStack)==True:
                    return True
            elif recStack[neighbour]==True:
                return True
        recStack[v]=False
        return False

    def isCyclic(self):
        visited=[False]*(self.V+1)
        recStack=[False]*(self.V+1)
        for node in range(self.V):
            if visited[node]==False:
                if self.isCyclicUtil(node,visited,recStack)==True:
                    return True
        return False

if __name__=='__main__':
    g=Graph(4)
    g.addEdge(0,1)
    g.addEdge(0,2)
    g.addEdge(1,2)
    g.addEdge(2,0)
    g.addEdge(2,3)
    g.addEdge(3,3)
    if g.isCyclic()==1:
        print("Graph contains cycle")
    else:
        print("Graph doesn't contain cycle")