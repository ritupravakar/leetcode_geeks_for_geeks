# https://www.geeksforgeeks.org/find-the-longest-path-in-a-matrix-with-given-constraints/

"""

Step 1: Initialize a matrix and set its size to n x n.
Step 2: Define a function “findLongestFromACell” that takes in a cell’s row and column index, the matrix, and a lookup table. If the cell is out of                     bounds or the subproblem has already been solved, return 0 or the previously calculated value in the lookup table, respectively.
Step 3: Define four integer variables to store the length of the path in each of the four possible directions. Check if the adjacent cell in each                          direction satisfies the constraints and if so, recursively call the function for that cell and update the corresponding direction’s length                           variable.
Step 4: Return the maximum length of the four directions plus one, and store it in the lookup table.
Step 5: Define a function “finLongestOverAll” that takes in the matrix. Initialize a result variable to 1 and a lookup table as a two-dimensional array              of size n x n, filled with -1.
Step 6: For each cell in the matrix, call “findLongestFromACell” and update the result as needed.
Step 7: Return the result.

"""

n=3
def findLongestFromACell(i,j,mat,dp):
    if (i<0 or i>=n or j<0 or j>=n):
        return 0

    if (dp[i][j]!=-1):
        return dp[i][j]
    x,y,z,w=-1,-1,-1,-1
    if (j<n-1 and ((mat[i][j]+1)==mat[i][j+1])):
        x=1+findLongestFromACell(i,j+1,mat,dp)
    if (j>0 and (mat[i][j]+1==mat[i][j-1])):
        y=1+findLongestFromACell(i,j-1,mat,dp)
    if (i>0 and (mat[i][j]+1==mat[i-1][j])):
        z=1+findLongestFromACell(i-1,j,mat,dp)
    if (i<n-1 and (mat[i][j]+1==mat[i+1][j])):
        w=1+findLongestFromACell(i+1,j,mat,dp)
    dp[i][j]=max(x,(max(y,max(z,max(w,1)))))
    return dp[i][j]

def finLongestOverAll(mat):
    result=1
    dp=[[-1 for i in range(n)] for i in range(n)]
    for i in range(n):
        for j in range(n):
            if (dp[i][j]==-1):
                findLongestFromACell(i,j,mat,dp)
            result=max(result,dp[i][j])
    return result
mat=[[1,2,9],[5,3,8],[4,6,7]]
print("Length of the longest path is ",finLongestOverAll(mat))