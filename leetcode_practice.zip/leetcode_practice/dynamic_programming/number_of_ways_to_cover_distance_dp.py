# https://www.geeksforgeeks.org/count-number-of-ways-to-cover-a-distance/

"""
Algorithm:

    Create an array of size n + 1 and initialize the first 3 variables with 1, 1, 2. The base cases.
    Run a loop from 3 to n.
    For each index i, compute value of ith position as dp[i] = dp[i-1] + dp[i-2] + dp[i-3].
    Print the value of dp[n], as the Count of number of ways to cover a distance.

"""

def printCountDP(dist):
    count=[0]*(dist+1)
    count[0]=1
    if dist>=1:
        count[1]=1
    if dist>=2:
        count[2]=2

    for i in range(3,dist+1):
        count[i]=(count[i-1]+count[i-2]+count[i-3])
    return count[dist]

dist=4
print(printCountDP(dist))