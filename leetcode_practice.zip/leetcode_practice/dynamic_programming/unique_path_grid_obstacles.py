# https://www.geeksforgeeks.org/unique-paths-in-a-grid-with-obstacles/

"""
Approach:

    Create a 2D matrix of the same size as the given matrix to store the results.
    Traverse through the created array row-wise and start filling the values in it.
    If an obstacle is found, set the value to 0.
    For the first row and column, set the value to 1 if an obstacle is not found.
    Set the sum of the right and the upper values if an obstacle is not present at that corresponding position in the given matrix
    Return the last value of the created 2d matrix


"""

def uniquePathsWithObstacles(A):
    paths=[[0]*len(A[0]) for i in A]
    if A[0][0]==0:
        paths[0][0]=1

    for i in range(1,len(A)):
        if A[i][0]==0:
            paths[i][0]=paths[i-1][0]

    for j in range(1,len(A[0])):
        if A[0][j]==0:
            paths[0][j]=paths[0][j-1]

    for i in range(1,len(A)):
        for j in range(1,len(A[0])):
            if A[i][j]==0:
                paths[i][j]=paths[i-1][j]+paths[i][j-1]

    return paths[-1][-1]

A=[[0,0,0],[0,1,0],[0,0,0]]
print(uniquePathsWithObstacles(A))