# https://www.geeksforgeeks.org/subset-sum-problem-dp-25/
"""
    So we will create a 2D array of size (n + 1) * (sum + 1) of type boolean. The state dp[i][j] will be true if there exists a subset of elements from set[0 . . . i] with sum value = ‘j’.
    The dynamic programming relation is as follows:
    if (A[i-1] > j)
        dp[i][j] = dp[i-1][j]
    else
        dp[i][j] = dp[i-1][j] OR dp[i-1][j-set[i-1]]
    This means that if the current element has a value greater than the ‘current sum value’ we will copy the answer for previous cases and if the current sum value is greater than the ‘ith’ element we will see if any of the previous states have already experienced the sum= j OR any previous states experienced a value ‘j – set[i]’ which will solve our purpose.
"""

def isSubsetSum(set,n,sum):
    subset=([[False for i in range(sum+1)] for i in range(n+1)])
    for i in range(n+1):
        subset[i][0]=True
    for i in range(1,sum+1):
        subset[0][i]=False
    for i in range(1,n+1):
        for j in range(1,sum+1):
            if j<set[i-1]:
                subset[i][j]=subset[i-1][j]
            if j>=set[i-1]:
                subset[i][j]=(subset[i-1][j] or subset[i-1][j-set[i-1]])
    return subset[n][sum]

if __name__=='__main__':
    set=[3,34,4,12,5,2]
    sum=9
    n=len(set)
    if (isSubsetSum(set,n,sum)==True):
        print("Found a subset with given sum")
    else:
        print("No subset with given sum")