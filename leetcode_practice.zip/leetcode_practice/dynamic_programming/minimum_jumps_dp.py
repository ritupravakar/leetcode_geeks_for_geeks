# https://www.geeksforgeeks.org/minimum-number-of-jumps-to-reach-end-of-a-given-array/

"""
It can be observed that there will be overlapping subproblems.
For example in array, arr[] = {1, 3, 5, 8, 9, 2, 6, 7, 6, 8, 9} minJumps(3, 9) will be called two times as arr[3] is reachable from arr[1] and arr[2]. So this problem has both properties (optimal substructure and overlapping subproblems) of Dynamic Programming

Follow the below steps to implement the idea:

    Create jumps[] array from left to right such that jumps[i] indicate the minimum number of jumps needed to reach arr[i] from arr[0].
    To fill the jumps array run a nested loop inner loop counter is j and the outer loop count is i.
        Outer loop from 1 to n-1 and inner loop from 0 to i.
        If i is less than j + arr[j] then set jumps[i] to minimum of jumps[i] and jumps[j] + 1. initially set jump[i] to INT MAX
    Return jumps[n-1].

"""

def minJumps(arr,n):
    jumps=[0 for i in range(n)]
    if (n==0) or (arr[0]==0):
        return float('inf')
    jumps[0]=0

    for i in range(1,n):
        jumps[i]=float('inf')
        for j in range(i):
            if (i<=j+arr[j]) and (jumps[j]!=float('inf')):
                jumps[i]=min(jumps[i],jumps[j]+1)
                break
    return jumps[n-1]
arr=[1,3,5,8,9,2,6,7,6,8,9]
size=len(arr)
print("Minimum number of jumps to reach end is ",minJumps(arr,size))