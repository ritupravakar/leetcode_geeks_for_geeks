# https://www.geeksforgeeks.org/longest-common-subsequence-dp-4/

"""
We can use the following steps to implement the dynamic programming approach for LCS.

    Create a 2D array dp[][] with rows and columns equal to the length of each input string plus 1 [the number of rows indicates the indices of S1 and the columns indicate the indices of S2].
    Initialize the first row and column of the dp array to 0.
    Iterate through the rows of the dp array, starting from 1 (say using iterator i).
        For each i, iterate all the columns from j = 1 to n:
            If S1[i-1] is equal to S2[j-1], set the current element of the dp array to the value of the element to (dp[i-1][j-1] + 1).
            Else, set the current element of the dp array to the maximum value of dp[i-1][j] and dp[i][j-1].
    After the nested loops, the last element of the dp array will contain the length of the LCS.
"""

def lcs(X,Y,m,n):
    L=[[None]*(n+1) for i in range(m+1)]
    for i in range(m+1):
        for j in range(n+1):
            if i==0 or j==0:
                L[i][j]=0
            elif X[i-1]==Y[j-1]:
                L[i][j]=L[i-1][j-1]+1
            else:
                L[i][j]=max(L[i-1][j],L[i][j-1])

    return L[m][n]
if __name__=='__main__':
    S1="abc"
    S2="abc"
    m=len(S1)
    n=len(S2)
    print("Length of LCS is",lcs(S1,S2,m,n))
