# https://www.geeksforgeeks.org/cutting-a-rod-dp-13/

"""
We can get the best price by making a cut at different positions and comparing the values obtained after a cut. We can recursively call the same function for a piece obtained after a cut.
Let cutRod(n) be the required (best possible price) value for a rod of length n. cutRod(n) can be written as follows.
cutRod(n) = max(price[i] + cutRod(n-i-1)) for all i in {0, 1 .. n-1}

"""

def cutRod(price,index,n):
    if index==0:
        return n*price[0]

    notCut=cutRod(price,index-1,n)
    cut=float("-inf")
    rod_length=index+1
    if (rod_length<=n):
        cut=price[index]+cutRod(price,index,n-rod_length)
    return max(notCut,cut)

arr=[1,5,8,9,10,17,17,20]
size=len(arr)
print("Maximum Obtainable Value is ",cutRod(arr,size-1,size))