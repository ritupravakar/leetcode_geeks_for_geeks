# https://www.geeksforgeeks.org/coin-change-dp-7/

"""
The coin change problem is a classic dynamic programming problem that involves finding the number of ways to make change for a given amount of money using a given set of coins. Here's a step-by-step solution for the coin change problem:
Define the problem: Given a target amount and a set of coin denominations, find the total number of unique ways to make change for the target amount using the coins.
Identify the subproblems: We can break the problem down into subproblems by considering the subproblem of making change for smaller amounts first. For each coin denomination, we can ask how many ways there are to make change for the remaining amount after subtracting the coin value.
Define the base cases: If the target amount is zero, there is exactly one way to make change (i.e., using no coins). If the target amount is negative, there are no ways to make change.
Define the recursive formula: Let dp[i] be the number of ways to make change for the amount i. Then we can calculate dp[i] for all i using the formula:

scss
Copy code
dp[i] = sum(dp[i - coin]) for coin in coins
This means that the number of ways to make change for i is the sum of the number of ways to make change for i - coin for all coin values in the set of coins.
Implement the solution: We can implement the above recursive formula using dynamic programming. We can create an array dp of length target + 1 and initialize it to zero. Then, we can set dp[0] = 1 as the base case. Next, for each coin value in the set of coins, we can iterate through i from coin to target and update dp[i] using the formula above.
Here's the code implementation of the coin change problem in Python:

less

def coin_change(coins, target):
    dp = [0] * (target + 1)
    dp[0] = 1
    for coin in coins:
        for i in range(coin, target + 1):
            dp[i] += dp[i - coin]
    return dp[target]

Analyze the time and space complexity: The time complexity of the above solution is O(target * n), where n is the number of coin denominations. The space complexity is also O(target), as we only need to store the dp array of length target + 1. This is a polynomial time complexity, which makes it efficient for small to medium-sized instances of the problem.
In summary, the above solution involves using dynamic programming to break down the problem into subproblems, defining base cases and a recursive formula, implementing the solution using an array, and analyzing the time and space complexity.


Follow the below steps to Implement the idea:

    Using 2-D vector to store the Overlapping subproblems.
    Traversing the whole array to find the solution and storing in the memoization table.
    Using the memoization table to find the optimal solution.



"""

def count(coins,n,sum):
    table=[[0 for x in range(n)] for x in range(sum+1)]
    for i in range(n):
        table[0][i]=1

    for i in range(1,sum+1):
        for j in range(n):
            x=table[i-coins[j]][j] if i-coins[j]>=0 else 0
            y=table[i][j-1] if j>=1 else 0
            table[i][j]=x+y
    print(table)
    return table[sum][n-1]

if __name__=='__main__':
    coins=[1,2,5]
    n=len(coins)
    sum=11
    print(count(coins,n,sum))