# https://www.geeksforgeeks.org/word-break-problem-dp-32/

def dictionaryContains(word):
    dictionary =["cats","dog","sand","and","cat"]
    size=len(dictionary)
    for i in range(size):
        if (dictionary[i]==word):
            return True
    return False

def wordBreak(Str):
    size=len(Str)
    if (size==0):
        return True
    wb=[False for i in range(size+1)]

    for i in range(1,size+1):
        if (wb[i]==False and dictionaryContains(Str[0:i])):
            wb[i]=True

        if (wb[i]==True):
            if (i==size):
                return True
            for j in range(i+1,size+1):
                if (wb[j]==False and dictionaryContains(Str[i:j])):
                    wb[j]=True
                if (j==size and wb[j]==True):
                    return True
    return False

if (wordBreak(("catsandog"))):
    print("Yes")
else:
    print("No")
