# https://www.geeksforgeeks.org/edit-distance-dp-5/
"""

We can see that many subproblems are solved, again and again, for example, eD(2, 2) is called three times.
 Since same subproblems are called again, this problem has Overlapping Subproblems property.
 So Edit Distance problem has both properties (see this and this) of a dynamic programming problem.
 Like other typical Dynamic Programming(DP) problems, recomputations of same subproblems can be avoided by constructing a temporary array that stores results of subproblems.

"""

def editDistDP(str1,str2,m,n):
    dp=[[0 for x in range(n+1)] for x in range(m+1)]
    for i in range(m+1):
        for j in range(n+1):
            if i==0:
                dp[i][j]=j
            elif j==0:
                dp[i][j]=i
            elif str1[i-1]==str2[j-1]:
                dp[i][j]=dp[i-1][j-1]
            else:
                dp[i][j]=1+min(dp[i][j-1],dp[i-1][j],dp[i-1][j-1])

    return dp[m][n]

str1="AACCGGTT"
str2="AAACGGTA"
print(editDistDP(str1,str2,len(str1),len(str2)))