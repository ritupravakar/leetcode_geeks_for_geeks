# https://www.geeksforgeeks.org/partition-a-set-into-two-subsets-such-that-the-difference-of-subset-sums-is-minimum/

""""
The task is to divide the set into two parts.
We will consider the following factors for dividing it.
Let
  dp[i][j] = {1 if some subset from 1st to i'th has a sum
                      equal to j
                   0 otherwise}

    i ranges from {1..n}
    j ranges from {0..(sum of all elements)}

So
    dp[i][j]  will be 1 if
    1) The sum j is achieved including i'th item
    2) The sum j is achieved excluding i'th item.

Let sum of all the elements be S.

To find Minimum sum difference, we have to find j such
that Min{sum - 2*j  : dp[n][j]  == 1 }
    where j varies from 0 to sum/2

The idea is, sum of S1 is j and it should be closest
to sum/2, i.e., 2*j should be closest to sum (as this will ideally minimize sum-2*j.

"""

import sys
def findMin(a,n):
    su=0
    su=sum(a)
    dp=[[0 for i in range(su+1)] for j in range(n+1)]
    for i in range(n+1):
        dp[i][0]=True

    for j in range(1,su+1):
        dp[0][j]=False

    for i in range(1,n+1):
        for j in range(1,su+1):
            dp[i][j]=dp[i-1][j]
            if a[i-1]<=j:
                dp[i][j]|=dp[i-1][j-a[i-1]]

    diff=sys.maxsize

    for j in range(su//2,-1,-1):
        if dp[n][j]==True:
            diff=su-(2*j)
            break
    return diff

a=[3,1,4,2,2,1]
n=len(a)

print("The minimum difference between 2 sets is ",findMin(a,n))