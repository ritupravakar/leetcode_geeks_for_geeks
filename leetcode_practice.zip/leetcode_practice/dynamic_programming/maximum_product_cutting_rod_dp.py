# https://www.geeksforgeeks.org/maximum-product-cutting-dp-36/

"""

In the above partial recursion tree, mP(3) is being solved twice. We can see that there are many subproblems which are solved again and again. Since same subproblems are called again, this problem has Overlapping Subproblems property. So the problem has both properties (see this and this) of a dynamic programming problem. Like other typical Dynamic Programming(DP) problems, recomputations of same subproblems can be avoided by constructing a temporary array val[] in bottom up manner.
"""

def maxProd(n):
    val=[0 for i in range(n+1)]
    for i in range(1,n+1):
        max_val=0
        for j in range(1,i):
            max_val=max(max_val,(i-j)*j,j*val[i-j])
        val[i]=max_val
    return val[n]


print("Maximum Product is ",maxProd(10))