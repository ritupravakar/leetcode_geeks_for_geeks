# https://www.geeksforgeeks.org/egg-dropping-puzzle-dp-11/

"""
In this approach, we work on the same idea as described above neglecting the case of calculating the answers to sub-problems again and again. The approach will be to make a table that will store the results of sub-problems so that to solve a sub-problem, would only require a look-up from the table which will take constant time, which earlier took exponential time.

Formally for filling DP[i][j] state where ‘i’ is the number of eggs and ‘j’ is the number of floors:
 We have to traverse for each floor ‘x’ from ‘1’ to ‘j’ and find a minimum of:

    (1 + max( DP[i-1][j-1], DP[i][j-x] )).
"""

INT_MAX=32767
def eggDrop(n,k):
    eggFloor=[[0 for x in range(k+1)] for x in range(n+1)]
    for i in range(1,n+1):
        eggFloor[i][1]=1
        eggFloor[i][0]=0
    for j in range(1,k+1):
        eggFloor[1][j]=j

    for i in range(2,n+1):
        for j in range(2,k+1):
            eggFloor[i][j]=INT_MAX
            for x in range(1,j+1):
                res=1+max(eggFloor[i-1][x-1],eggFloor[i][j-x])
                if res<eggFloor[i][j]:
                    eggFloor[i][j]=res
    return eggFloor[n][k]

if __name__=="__main__":
    n=2
    k=36
    print("Minimum number of trials in worst case with "+str(n)+" eggs and "+str(k)+" floors is "+str(eggDrop(n,k)))