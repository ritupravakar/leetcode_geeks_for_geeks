class Node:
    def __init__(self):
        self.data=0
        self.next=None

def append(head_ref,new_data):
    new_node=Node()
    new_node.data=new_data
    new_node.next=head_ref
    head_ref=new_node
    return head_ref

def printList(head):
    if (not head):
        return

    while (head.next!=None):
        print(head.data,end=' -> ')
        head=head.next
    print(head.data)

def find_mid(head):
    temp=head
    slow=head
    fast=head

    while (fast and fast.next):
        slow=slow.next
        fast=fast.next.next
    if (fast):
        slow=slow.next
    return slow

def modifyTheList(head,slow):
    s=[]
    temp=head
    while (slow):
        s.append(slow.data)
        slow=slow.next

    while (len(s)!=0):
        temp.data=temp.data-s[-1]
        temp=temp.next
        s.pop()

if __name__=="__main__":
    head=None
    head=append(head,10)
    head=append(head,7)
    head=append(head,12)
    head=append(head,8)
    head=append(head,9)
    head=append(head,2)
    mid=find_mid(head)
    modifyTheList(head,mid)
    print("Modified List:")
    printList(head)