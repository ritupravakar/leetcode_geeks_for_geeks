class Node:
    def __init__(self):
        self.data=0
        self.next=None
        self.prev=None
def deleteNode(head_ref,del_):
    if (head_ref==None or del_==None):
        return None
    if (head_ref==del_):
        head_ref=del_.next

    if (del_.next!=None):
        del_.next.prev=del_.prev

    if (del_.prev!=None):
        del_.prev.next=del_.next
    return head_ref

def removeDuplicates(head_ref):
    if ((head_ref)==None):
        return None
    us=set()
    current=head_ref
    next=None
    while (current!=None):
        if ((current.data) in us):
            next=current.next
            head_ref=deleteNode(head_ref,current)
            current=next
        else:
            us.add(current.data)
            current=current.next
    return head_ref

def push(head_ref,new_data):
    new_node=Node()
    new_node.data=new_data
    new_node.prev=None
    new_node.next=(head_ref)
    if ((head_ref)!=None):
        (head_ref).prev=new_node
    (head_ref)=new_node
    return head_ref

def printList(head):
    if (head==None):
        print("Doubly Linked list empty")
    while(head!=None):
        print(head.data,end=" ")
        head=head.next

head=None
head=push(head,12)
head=push(head,12)
head=push(head,10)
head=push(head,4)
head=push(head,8)
head=push(head,4)
head=push(head,6)
head=push(head,4)
head=push(head,4)
head=push(head,8)

print("Original Doubly linked list: ")
printList(head)

head=removeDuplicates(head)
print("\nDoubly linked list after removing duplicates: ")
printList(head)