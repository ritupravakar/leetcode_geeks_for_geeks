class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
        self.prev=None

class DoublyLinkedList:
    def __init__(self):
        self.head=None

    def getNode(self,data):
        return Node(data)

    def sortedInsert(self,data):
        new_node=self.getNode(data)
        if self.head is None:
            self.head=new_node

        elif self.head.data>=new_node.data:
            new_node.next=self.head
            new_node.next.prev=new_node
            self.head=new_node
        else:
            current=self.head
            while ((current.next is not None) and (current.next.data<new_node.data)):
                current=current.next

            new_node.next=current.next
            if current.next is not None:
                new_node.next.prev=new_node

            current.next=new_node
            new_node.prev=current
    def printList(self):
        node=self.head
        while node:
            print(str(node.data),end=" ")
            node=node.next

if __name__=='__main__':
    llist=DoublyLinkedList()
    llist.sortedInsert(8)
    llist.sortedInsert(5)
    llist.sortedInsert(3)
    llist.sortedInsert(10)
    llist.sortedInsert(12)
    llist.sortedInsert(9)

    print("Created Doubly Linked List")
    llist.printList()
