class Node:
    def __init__(self,x):
        self.data=x
        self.next=None
        self.prev=None

def pairSum(head,x):
    first=head
    second=head
    while(second.next!=None):
        second=second.next
    found=False
    while (first!=second and second.next!=first):
        if ((first.data+second.data)==x):
            found=True
            print("(",first.data,",",second.data,")")
            first=first.next
            second=second.prev
        else:
            if ((first.data+second.data)<x):
                first=first.next
            else:
                second=second.prev

    if (found==False):
        print("No pair found")

def insert(head,data):
    temp=Node(data)
    if not head:
        head=temp
    else:
        temp.next=head
        head.prev=temp
        head=temp
    return head

if __name__=='__main__':
    head=None
    head=insert(head,9)
    head=insert(head,8)
    head=insert(head,6)
    head=insert(head,5)
    head=insert(head,4)
    head=insert(head,2)
    head=insert(head,1)
    x=7
    pairSum(head,x)
