class Node:
    def __init__(self,data):
        self.data=data
        self.next=None

def deleteNode(head,val):
    if (head==None):
        print("Element not present in the list")
        return -1
    if (head.data==val):
        if head.next:
            head.data=head.next.data
            head.next=head.next.next
            return 1
        else:
            return 0

    if deleteNode(head.next,val)==0:
        head.next=None
        return 1

def push(head,data):
    newNode=Node(data)
    newNode.next=head
    head=newNode
    return head

def printLL(head):
    if (head==None):
        return
    temp=head
    while temp:
        print(temp.data,end=' ')
        temp=temp.next
    print()

head=None
head=push(head,10)
head=push(head,12)
head=push(head,14)
head=push(head,15)
printLL(head)
deleteNode(head,20)
printLL(head)
deleteNode(head,10)
printLL(head)
deleteNode(head,14)
printLL(head)